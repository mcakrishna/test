var express = require('express');
var app = express();

var UserController = require('./user/UserController');
var yahooController = require('./yahoo/yahooController');
var yahooPractice = require('./yahoo/yahooPracticeController');
var share  = require('./Share/ShareController');
app.use('/share', share);
app.use('/users', UserController);
app.use('/yahoo', yahooController);
module.exports = app;