var unirest = require('unirest');
var request = require('request');
var isJSON = require('is-valid-json');
const cheerio = require('cheerio')

var contract = {
    GetData: function (scribe,period, callback) { 
        var url = 'https://www.nseindia.com/live_market/dynaContent/live_watch/option_chain/optionKeys.jsp?symbol=' + scribe + '&instrument=OPTSTK&date=' + period;
        console.log(url)
        request(url, function(err, resp, body) {       
            
            

            
            callback(body);
            // var list=[];   
            // $($(html).find('#octable > tbody  > tr')).each(function (i, row) {


            //     if ($(this).find("td").eq(1)[0] != "Total") {
            //        var html1 =  $(html).find('table')[0]
            //        var stringRate = html1.firstChild.firstElementChild.children[1].firstElementChild.firstElementChild.firstElementChild.innerText;

            //         var ratescribe =parseFloat(stringRate.replace(value.scribe, ''));
                    
            //         var object = new Object();
            //         object.Symbol = value.scribe;
            //         object.lot = parseInt(value.lot);
            //         object.CallOpenInterest = convertFloat($(this).find("td").eq(1)[0]);
            //         object.CallChangeInOpenInterest = convertFloat($(this).find("td").eq(2)[0]);
            //         object.CallVolumne = convertFloat($(this).find("td").eq(3)[0]);
            //         object.CallIV = convertFloat($(this).find("td").eq(4)[0]);
            //         object.CallLTP = convertFloat($(this).find("td").eq(5)[0]);
            //         object.CallNetChange = convertFloat($(this).find("td").eq(6)[0]);
            //         object.CallValue = object.lot * object.CallLTP;
            //         object.CallBidQty = convertFloat($(this).find("td").eq(7)[0]);
            //         object.CallBidPrice = convertFloat($(this).find("td").eq(8)[0]);
            //         object.CallAskPrice = convertFloat($(this).find("td").eq(9)[0]);
            //         object.CallAskQty = convertFloat($(this).find("td").eq(10)[0]);
            //         object.StrikePrice = convertFloat($(this).find("td").eq(11)[0]);
            //         object.PutBidQty = convertFloat($(this).find("td").eq(12)[0]);
            //         object.PutBidPrice = convertFloat($(this).find("td").eq(13)[0]);
            //         object.PutAskPrice = convertFloat($(this).find("td").eq(14)[0]);
            //         object.PutAskQty = convertFloat($(this).find("td").eq(15)[0]);
            //         object.PutNetChange = convertFloat($(this).find("td").eq(16)[0]);
            //         object.PutLTP = convertFloat($(this).find("td").eq(17)[0]);
            //         object.PutValue = object.lot * object.PutLTP;
            //         object.PutIV = convertFloat($(this).find("td").eq(18)[0]);
            //         object.PutVolumne = convertFloat($(this).find("td").eq(19)[0]);
            //         object.PutChangeOpenInterest = convertFloat($(this).find("td").eq(20)[0]);
            //         object.PutOpenInterest = convertFloat($(this).find("td").eq(21)[0]);
                    
            //         // var rate = $('#Rate').val();
            //         // if ((object.CallValue <= rate || object.PutValue <= rate) &  object.StrikePrice !=0) {
            //         //     object.Rate = ratescribe;
            //         //     if((object.Rate -  object.StrikePrice).toFixed(2) < 0 )
            //         //     {
            //         //         object.Change = parseFloat(  (-1 * (object.Rate -  object.StrikePrice).toFixed(2)));
            //         //     }
            //         //     else
            //         //     {
            //         //         object.Change = parseFloat( (object.Rate -  object.StrikePrice).toFixed(2));
            //         //     }
            //             list.push(object);
                        
                     
            //         // }
            //     }

                
            // });

            
         
        });

    }
 
}

module.exports = contract